#include "los_task.h"
#include "los_debug.h"
#include "Answer1_Demo.h"

static VOID *ShellRegTaskEntry(UINT32 arg)
{
    (VOID)arg;
    (VOID)ShellRegisterTask();
    return NULL;
}

unsigned int LosAppInit(VOID)
{
    UINT32 ret;
    UINT32 taskId;
    TSK_INIT_PARAM_S taskParam = { 0 };

    ret = SystemInit();
    if (ret != LOS_OK) {
        return ret;
    }

    taskParam.pfnTaskEntry = (TSK_ENTRY_FUNC)ShellRegTaskEntry;
    taskParam.uwStackSize = 0x1000;
    taskParam.pcName = "ShellRegTask";
    taskParam.usTaskPrio = 5;
    (VOID)LOS_TaskCreate(&taskId, &taskParam);

    return LOS_OK;
}
